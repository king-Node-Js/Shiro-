const Discord = require('discord.js')
const db = require('quick.db')

module.exports = async (bot, message, args, member) => {
  
  
 let ola = db.get(`bemvindo_${message.guild.id}`) 

if(ola === null) {
  return;
}
let embed = new Discord.MessageEmbed()
.setColor("BLACK")
.setTitle("Bem vindo")
.setDescription(`Ola seja bem vindo \n\n📃**Leia as regras em #regras**\n\n👤**Sabia que o nosso servidor e muito divertido?**\n\n**que voce se divirta junto** 🤪🤪`)
 .setImage("https://cdn.discordapp.com/attachments/762862995080216607/768913148006498384/videotogif_2020.10.22_16.04.14.gif")

bot.channels.cache.get(ola).send(embed)
 
}