module.exports = async (bot) => { //faz algo qdo o bot liga
  console.log('!!! estou pronto para ser usado !!!\n  To de olho em '+bot.channels.cache.size+' canais (chats + calss)');

  const avatares = [
    "https://cdn.discordapp.com/attachments/762862995080216607/769222370849849424/Screenshot_20201023-1232462.png",
    "https://cdn.discordapp.com/attachments/762862995080216607/769222371164553216/Screenshot_20201023-1232572.png",
    "https://cdn.discordapp.com/attachments/762862995080216607/769222371407560724/Screenshot_20201023-1233392.png",
    "https://cdn.discordapp.com/attachments/762862995080216607/769222371629596672/Screenshot_20201023-1223382.png"//avatares para o bot ficar alterando.
  ] 
  
  const status = [
    "online",
    "dnd",
    "idle"
  ]
  
  const atividades = [
     ["🐢 estou dando toda segurança para "+bot.guilds.cache.size+" servidores.", "LISTENING"],
     ["🔩 Você sabia que eu sou open source?", "PLAYING"],
     ["🖤 tentando deixar seu grupo o mais seguro o possivel.", "WATCHING"],
     ["📡 venha para o meu suporte usando "+bot.prefixo+"suporte", "WATCHING"],
     ["😁 tenho "+bot.users.cache.size+" amigos", "PLAYING"],
     ["🤓 estou olhando "+bot.channels.cache.size+" Canais", "WATCHING"]
    ];
  setInterval(async () => { // controlar o intervalo
    let i = Math.floor(Math.random() * atividades.length + 1) - 1
      await bot.user.setActivity(atividades[i][0], { type: atividades [i][1] });
  }, 10000); // intervalo

  setInterval(async () => {
    let b = Math.floor(Math.random() * status.length + 1) - 1
      await bot.user.setStatus(status[b])
  }, 20000)

  setInterval(async () => {
    let c = Math.floor(Math.random() * avatares.length + 1) - 1
      await bot.user.setAvatar(avatares[c])
  }, 400000)

}