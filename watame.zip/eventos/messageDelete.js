const Discord = require('discord.js')
const db = require('quick.db')

module.exports = async (bot, message) => {
  
  
 let audit = db.get(`auditchannel_${message.guild.id}`) 

if(audit === null) {
  return;
}

let embed = new Discord.MessageEmbed()
.setColor("RED")
.setTitle(message.author.tag)
    .setDescription("📝**Menssagem de texto deletada**\n\n**Canal de texto:**<#"+message.channel.id+">\n\n Menssagem\n `"+message.content+"`")  

bot.channels.cache.get(audit).send(embed)
}