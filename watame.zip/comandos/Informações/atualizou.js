const discord = require('discord.js')



exports.run = async(bot, message, args) => {
  
  message.delete()
  let embed = new discord.MessageEmbed()
  .setColor('00FFFF')
  .setTitle('Bot Update')
  .setDescription(`Ola @everyone, Vim lhes informar que eu passei por 1 Atualização\n\nOque esta esperando? me adicione e confira as novidades`)

bot.channels.cache.get('764214968135450655').send(embed)

}