const discord = require('discord.js')



exports.run = async(bot, message, args) => {
  
  message.delete()
  let embed = new discord.MessageEmbed()
  .setColor('FF0000')
  .setTitle('Bot Update')
  .setDescription(`Ola @everyone, Vim lhes informar que estarei passando por uma atualização onde sera adicionado novos comandos ou sera corrigido erros em meu sistema`)
  
bot.channels.cache.get('764214968135450655').send(embed)
}