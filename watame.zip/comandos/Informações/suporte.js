const discord = require('discord.js')

exports.run = async(bot, message, args) =>{
  
  let embed = new discord.MessageEmbed()
  .setTitle('Meu servidor de suporte')
  .setColor('00FFFF')
  .setDescription(`\n[Clique aqui!](https://discord.gg/T6D9VFm)`)
  
  message.channel.send(embed)
}