const Discord = require('discord.js');
const fs = require('fs');

module.exports.run = async (bot, message, args) => {


const embed = new Discord.MessageEmbed()
.setTitle(`<:watame:768956955409645619>Shiro™ 𖧹 3.0`)
.setColor('RED')
.setDescription(`Ola <@${message.author.id}>,**me chamo Shiro™ sou uma bot de Moderação e diversão Aqui esta meu painel de controle**\n\n<a:alertaword:768957203284492298>**Mas antes**<a:alertaword:768957203284492298>\n[Me adicione plz](https://discord.com/oauth2/authorize?client_id=761894399319212073&scope=bot&permissions=268437562)\n\n<a:0_GTKF:768936732737142806>Moderação\n<a:1_GTKF:768936706077753346>Diversão\n<a:2_GTKF:768936745399746631>infos`);


message.channel.send(embed).then(async msg => {
  msg.react('768936732737142806');
  msg.react('768936706077753346');
  msg.react('768936745399746631');

  const filter = (reaction, user) => user.id === message.author.id;

  const collector = msg.createReactionCollector(filter);

  collector.on('collect', async r => {
      if (r.emoji.id === '768936732737142806'){
        embed.setDescription('<a:5AM_BlackSeta:769155832893407282>**mute**``Muta um usuário``\n<a:5AM_BlackSeta:769155832893407282>**muterole**``define um muterole``\n<a:5AM_BlackSeta:769155832893407282>**ban**``bani um usuário``\n<a:5AM_BlackSeta:769155832893407282>**giveaway**``faz um sorteio``\n<a:5AM_BlackSeta:769155832893407282>**clear**``exclui mensagens``\n<a:5AM_BlackSeta:769155832893407282>**warn**``avisa um jogador``\n<a:5AM_BlackSeta:769155832893407282>**avisos**``ve os warns de 1 usuário``\n<a:5AM_BlackSeta:769155832893407282>**reset-warn**``reseta os warns de um usuário``\n<a:5AM_BlackSeta:769155832893407282>**setbemvindo**``seta o canal de saida para mensagem de bem vindo``\n<a:5AM_BlackSeta:769155832893407282>**setregistro**``seta o canal para as Mensagens deletadas``');
    msg.reactions.removeAll()
msg.react('769155577967673364');
        msg.edit(embed);
      }

    
      if (r.emoji.id === '768936706077753346'){
        embed.setTitle('**Comandos de Diversão**');
        embed.setDescription('Painel de controle \n\n<a:5AM_BlackSeta:769155832893407282>**bolsonaro**``Memes com bolsonaro``\n<a:5AM_BlackSeta:769155832893407282>**Bolsonaro 2**``memes com bolsonaro 2``\n<a:5AM_BlackSeta:769155832893407282>**coinflip**``jogue cara ou coroa``\n<a:5AM_BlackSeta:769155832893407282>**kiss**``beija um usuário``\n<a:5AM_BlackSeta:769155832893407282>**hug**``abraça alguem``\n<a:5AM_BlackSeta:769155832893407282>**cafune**``faz cafune em alguem``\n<a:5AM_BlackSeta:769155832893407282>**Slap**``bate em alguém``\n\n');
        
msg.reactions.removeAll()
msg.react('769155577967673364');
        msg.edit(embed);
      }
      
      if (r.emoji.id === '769155577967673364'){
        embed.setTitle(`<:watame:768956955409645619>🌙Watame manage 𖧹 3.0`)
        embed.setDescription(`Ola <@${message.author.id}>,**me chamo 🌙 Watame manage™ sou uma bot de Moderação e diversão Aqui esta meu painel de controle**\n\n<a:alertaword:768957203284492298>**Mas antes**<a:alertaword:768957203284492298>\n[Me adicione plz](https://discord.com/oauth2/authorize?client_id=761894399319212073&scope=bot&permissions=268437562)\n<a:0_GTKF:768936732737142806>Moderação\n<a:1_GTKF:768936706077753346>Diversão\n<a:2_GTKF:768936745399746631>**infos**`)

msg.reactions.removeAll()
msg.react('768936732737142806');
  msg.react('768936706077753346');
  msg.react('768936745399746631')

      msg.edit(embed);
      }
      
      if (r.emoji.id === '768936745399746631'){
        embed.setTitle('Comandos de Infos')
        embed.setColor('RED')
        embed.setDescription('Bem vindo al painel de infos\n\n<a:5AM_BlackSeta:769155832893407282>**userinfo**``da as informações de um usuário``\n<a:5AM_BlackSeta:769155832893407282>**botinfo**``da as informações da bot``\n<a:5AM_BlackSeta:769155832893407282>**roleinfo**``da as infos de um cargo``')
       
        msg.reactions.removeAll()
        msg.react('769155577967673364');
    
        msg.edit(embed);
      }
  });
})

}