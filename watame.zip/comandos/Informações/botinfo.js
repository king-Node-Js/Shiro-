const discord = require('discord.js');

exports.run = async(bot, message, args) => {

let embed = new discord.MessageEmbed()

 .setColor('4cd8b2')
  .setTitle('Shiro™ 3.0')
  .setDescription("<a:A_FogoAmarelo2GTKF:768936856091492364> | **Olá <@"+message.author.id+">, Me chamo** ``Shiro™`` **sou uma bot de moderação e de diversão para seu discord!**\n**Use** ``s-ajuda ou s-help`` **Para ver meus comandos!**\n\n<a:ferramentas:769225852733882448> | **Meu prefixo nesse servidor e:**\n``s-``\n<:verfied:769162729402531860> | **Fui criada pelo:**\n``ひどい#0001``\n<a:CO_QUENEN:768936027477246002> | **Dia que fui criada:**\n``3/10/2020``\n<:setaword:769155724919046174> | **Me adicione:**\n[Clicando aqui](https://discord.com/oauth2/authorize?client_id=761894399319212073&scope=bot&permissions=10286)\n\n<a:tadahype:768935941733220372> | servidores: **"+bot.guilds.cache.size+"**\n<a:CO_pepepeek:768936087200071710> | canais: **"+bot.channels.cache.size+"**\n<a:5AM_yay:769228588666585128> | amigos:**"+bot.users.cache.size+"**\n\n<:bfdonline:769229218461515827> | **Meu suporte**\n[clique aqui](https://discord.gg/T6D9VFm)\n<a:black:769229652363051058> | **Linguagem**\n``Node.js``")
  message.channel.send(embed)

 }