const { MessageEmbed } = require('discord.js');
const db = require('quick.db');
//
module.exports = {
    name: 'coins',
    aliases: ['saldo', 'money', 'coin'],
    category: 'Economia',
    description: 'Veja a quantidade de coins que voce tem.',
    usage: `coins`,
//
run: async (client, message, args) => {
    var person = message.mentions.users.first() || message.author;
    var maos = db.fetch(`economia_maos_${message.guild.id}_${person.id}`)
    var banco = db.fetch(`economia_banco_${message.guild.id}_${person.id}`)
    //
    //
    let frasebanco;
    if (db.fetch(`economia_banco_${message.guild.id}_${person.id}`) !== 1) frasebanco = `coins`;
    if (db.fetch(`economia_banco_${message.guild.id}_${person.id}`) === null) frasebanco = `Voce nao tem coins depositado no banco.`;
    //
    let frasecoin;
    if (db.fetch(`economia_maos_${message.guild.id}_${person.id}`) !== 1) frasecoin = `coins`;
    if (db.fetch(`economia_maos_${message.guild.id}_${person.id}`) === null) frasecoin = `voce nao tem money.`;
    const embed = new MessageEmbed()
        .setColor('#36393F')
        .addField(`usuario`, person.username, true)
        .addField('💸Money da Shiro™',  `Em maos:** \n ${maos} ${frasecoin}`,
                `conta bancaria:** \n ${banco} ${frasebanco}`,
            )
    //
    await message.channel.send(embed);
}
}