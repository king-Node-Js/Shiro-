const Discord = require("discord.js")
const db = require("quick.db")

module.exports = {
  name: "setaudit-log",
  category: "configuração",
  usage: "setaudit-log <#channel>",
  description: "Set the adv channel",
  run: (client, message, args) => {
    
    let channel = message.mentions.channels.first()
    
        if (!message.member.hasPermission("ADMINISTRATOR")) return message.reply(`apenas usuários com a permissão \`ADMINITRADOR\` podem utilizar este comando!`)
    
    if(!channel) {
      return message.channel.send("<a:aredbravo_KOM:761437334210084905> Mencione algum canal!")
    }
    
    db.set(`auditchannel_${message.guild.id}`, channel.id)
    
    db.set(`edit_${message.guild.id}`, channel.id)
    
    
    message.channel.send(` Canal de auditoria setado para: ${channel}`)
  }
}
