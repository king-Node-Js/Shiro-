const { MessageEmbed } = require("discord.js");
const ms = require("ms");
module.exports = {
  name: "giveaway",
  description: "Create a simple giveaway",
  usage: "<time> <channel> <prize>",
  category: "fun",
  run: async (bot, message, args) => {
    if (!args[0]) return message.channel.send(`Por Favor Utilize os seguintes metodos: s!sorteio (tempo) (chat) (premio);`);
    if (
      !args[0].endsWith("d") &&
      !args[0].endsWith("h") &&
      !args[0].endsWith("m")
    )
      return message.channel.send(
        `Voce não usou a formatação correta para o tempo!`
      );
    if (isNaN(args[0][0])) return message.channel.send(` Isto não e um numero.`);
    let channel = message.mentions.channels.first();
    if (!channel)
      return message.channel.send(
        ` Eu nao achei esse canal na guilda.`
      );
    let prize = args.slice(2).join(" ");
    if (!prize) return message.channel.send(` Não tem um premio especificado!`);
    message.channel.send(`* Sorteio criado em ${channel}*`);
    let Embed = new MessageEmbed()
      .setTitle(` Novo Sorteio!`)
      .setDescription(
        `Reaja com 🎉 para entrar
Hospedado por ${message.author} 
Premio: **${prize}**`
      )
      .setTimestamp(Date.now() + ms(args[0]))
      .setColor(`BLUE`);
    let m = await channel.send(Embed);
    m.react("🎉");
    setTimeout(() => {
      if (m.reactions.cache.get("🎉").count <= 1) {
        message.channel.send(` Reactions: ${m.reactions.cache.get("🎉").count}`);
        return message.channel.send(
          `Not enough people reacted for me to start draw a winner!`
        );
      }
      /*marcaçao da watame*/

      let winner = m.reactions.cache
        .get("🎉")
        .users.cache.filter((u) => !u.bot)
        .random();
      channel.send(
        `O Ganhador do sorteio: **${prize}**... ${winner}`
      );
    }, ms(args[0]));
  },
};