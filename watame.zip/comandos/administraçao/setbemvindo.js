const Discord = require("discord.js")
const db = require("quick.db")

module.exports = {
  name: "setbem vindo",
  category: "configuração",
  usage: "set welcome <#channel>",
  description: "Set the adv channel",
  run: (client, message, args) => {
    
    let channel = message.mentions.channels.first()
    
        if (!message.member.hasPermission("ADMINISTRATOR")) return message.reply(`apenas usuários com a permissão \`ADMINITRADOR\` podem utilizar este comando!`)
    
    if(!channel) {
      return message.channel.send("Mencione algum canal!")
    }
    
    db.set(`bemvindo_${message.guild.id}`, channel.id)
    
    db.set(`edit_${message.guild.id}`, channel.id)
    
    
    message.channel.send(` Canal de bemvindo setado para: ${channel}`)
  }
}
