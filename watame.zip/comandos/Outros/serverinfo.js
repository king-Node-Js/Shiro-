const Discord = require('discord.js');
const client = new Discord.Client();
module.exports.run = (client, message, args) => {

    const moment = require("moment")
    moment.locale("pt-BR")
    let online = message.guild.members.filter(a => a.presence.status == "online").size;
    let ocupado = message.guild.members.filter(a => a.presence.status == "dnd").size;
    let ausente = message.guild.members.filter(a => a.presence.status == "idle").size;
    let offline = message.guild.members.filter(a => a.presence.status == "offline").size;
    let bot = message.guild.members.filter(a => a.user.bot).size;
    let totalmembros = message.guild.memberCount;
    let canaistexto = message.guild.channels.filter(a => a.type === "text").size;
    let canaisvoz = message.guild.channels.filter(a => a.type === "voice").size;
    let cargos = message.guild.roles.map(a => a).join(", ")
    
        const embed = new Discord.MessageEmbed()
        .setTitle('<:pasta:753639072425312346> | Informações do servidor!')
        .setColor('#72DFA2')
        .setThumbnail(message.guild.iconURL)
        .addField('<:servidor1:755253777329684580> ID do servidor', `${message.guild.id}`)
        .addField('<a:Coroa:755253487104819270> Criador do servidor', `<@${message.guild.owner.id}>`)
        .addField(`<:canais:755253287980367924> Canais (${canaistexto+canaisvoz})`, `<:chat:755253408486916097> texto (**${canaistexto}**)\n<:vozz:755253213007052881> Voz: (**${canaisvoz}**)`)
        .addField('<:data1:755253151451316355> Criado em:', moment(message.guild.createdAt).format('LLLL'))
        .addField(`<:usuario:755253067359715418> Membros (${totalmembros})`, `<:online:751808487968866354> Online: **(${online})**\n<:ausente:755209692849897513> Ausente: **(${ausente})**\n<:dnd:751808504762859570> Ocupado: **(${ocupado})**\n<:offline:751808523964252191> Offline: **(${offline})**`)
        .setFooter(`Comando solicitado por: ${message.author.tag}`, `${message.author.avatarURL}`)
        .setTimestamp()

        message.channel.send(embed)
}

module.exports.info = { 
    name: "serverinfo",
    aliases: ["infoserver"]
}