const Discord = require('discord.js');

exports.run = async (client, message, args) => {

var list = [
  'https://media.tenor.com/images/c7192cc8ffa738690156fbb9334a8937/tenor.gif',
  'https://media.tenor.com/images/c5acf899741117647a56c80ad6f459ca/tenor.gif',
  'https://media.tenor.com/images/d5c734a475142572d2d8a2ffec89c26e/tenor.gif',
  'https://media.tenor.com/images/bb4471bdc56bb2cf355338059d9fe4a0/tenor.gif'
];

var rand = list[Math.floor(Math.random() * list.length)];
let user = message.mentions.users.first() || client.users.cache.get(args[0]);
if (!user) {
return message.reply('lembre-se de mencionar um usuário válido para fazer um cafune!');
}
/*
message.channel.send(`${message.author.username} **acaba de beijar** ${user.username}! :heart:`, {files: [rand]});
*/
let avatar = message.author.displayAvatarURL({format: 'png'});
  const embed = new Discord.MessageEmbed()
        .setTitle('')
        .setColor('#000000')
        .setDescription(`${message.author} acaba de fazer um cafune em ${user}`)
        .setImage(rand)
        .setTimestamp()
        .setThumbnail(avatar)
        .setFooter('O-O sem palavras')
        .setAuthor(message.author.tag, avatar);
  await message.channel.send(embed);
}