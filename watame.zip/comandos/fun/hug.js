const Discord = require('discord.js');

exports.run = async (client, message, args) => {

var list = [
  'https://media.tenor.com/images/028e3a301c2e549e4fad471dc566f313/tenor.gif',
  'https://media.tenor.com/images/e8ec350d7ce836327eea6a6b7718e7c1/tenor.gif',
  'https://media.tenor.com/images/c9cfa5f10eb5aeeeba768ca4d2595a32/tenor.gif',
  'https://media.tenor.com/images/0475c99c7a2dd692012d9e705e2ba667/tenor.gif'
];

var rand = list[Math.floor(Math.random() * list.length)];
let user = message.mentions.users.first() || client.users.cache.get(args[0]);
if (!user) {
return message.reply('lembre-se de mencionar um usuário válido para abraçar!');
}
/*
message.channel.send(`${message.author.username} **acaba de beijar** ${user.username}! :heart:`, {files: [rand]});
*/
let avatar = message.author.displayAvatarURL({format: 'png'});
  const embed = new Discord.MessageEmbed()
        .setTitle('')
        .setColor('#000000')
        .setDescription(`${message.author} acaba de abraçar ${user}`)
        .setImage(rand)
        .setTimestamp()
        .setThumbnail(avatar)
        .setFooter('nss que abraço apertado')
        .setAuthor(message.author.tag, avatar);
  await message.channel.send(embed);
}