const jimp = require("jimp")

exports.run = async (client, message, args) => {

        let img = jimp.read("https://cdn.discordapp.com/attachments/736251986671829063/756744778800168960/bolsonaro_tv2.png")
        if(!args[0]) 
return message.channel.send(`<a:alert:753135168255950850> Escreva algo!`)
        img.then(image => {
            jimp.loadFont(jimp.FONT_SANS_32_BLACK).then(font => {
                image.resize(685, 494)
                image.print(font, 378, 158, args.join(" "), 600)
                image.getBuffer(jimp.MIME_PNG, (err, i) => {
                    message.channel.send({files: [{ attachment: i, name: "bolsonaro.png"}]})
                })
            })
        })
    }