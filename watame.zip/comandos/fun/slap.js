const Discord = require('discord.js');

exports.run = async (client, message, args) => {

var list = [
  'https://media.tenor.com/images/45a27dba6f60c6a8deee02335dd5f1a0/tenor.gif',
  'https://media.tenor.com/images/734d628ba871022bc9ae142035b969b5/tenor.gif',
  'https://media.tenor.com/images/53b846f3cc11c7c5fe358fc6d458901d/tenor.gif',
  'https://media.tenor.com/images/0ecd307be82e5aedbe13215bffbcd675/tenor.gif',
  'https://media.tenor.com/images/c366bb3a5d7820139646d8cdce96f7a8/tenor.gif',
  'https://media.tenor.com/images/5f2ff2ae7cea4fc3f1e701606dec84f8/tenor.gif',
  'https://media.tenor.com/images/a0c111e14b73a5ff9a876eb6beab6729/tenor.gif',
  'https://media.tenor.com/images/3f9e6d5315b421c11cff659cd4a7a25e/tenor.gif',
  'https://media.tenor.com/images/b09b36ae92b2b5c6da7212472514063d/tenor.gif'
];

var rand = list[Math.floor(Math.random() * list.length)];
let user = message.mentions.users.first() || client.users.cache.get(args[0]);
if (!user) {
return message.reply('lembre-se de mencionar um usuário válido para abraçar!');
}
/*
message.channel.send(`${message.author.username} **acaba de beijar** ${user.username}! :heart:`, {files: [rand]});
*/
let avatar = message.author.displayAvatarURL({format: 'png'});
  const embed = new Discord.MessageEmbed()
        .setTitle('')
        .setColor('#000000')
        .setDescription(`${message.author} acaba de bater em ${user}`)
        .setImage(rand)
        .setTimestamp()
        .setThumbnail(avatar)
        .setFooter('kkkkkkk depois de uma dessas eu revidava com ``w-slap``')
        .setAuthor(message.author.tag, avatar);
  await message.channel.send(embed);
}