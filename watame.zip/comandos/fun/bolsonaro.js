const jimp = require("jimp")

exports.run = async (client, message, args) => {

        let img = jimp.read("https://cdn.discordapp.com/attachments/737026333120397322/756739840409600071/bolsonaro_tv.png")
        if(!args[0]) 
return message.channel.send(`<a:alert:753135168255950850> Escreva algo!`)
        img.then(image => {
            jimp.loadFont(jimp.FONT_SANS_32_BLACK).then(font => {
                image.resize(685, 490)
                image.print(font, 365, 183, args.join(" "), 600)
                image.getBuffer(jimp.MIME_PNG, (err, i) => {
                    message.channel.send({files: [{ attachment: i, name: "bolsonaro.png"}]})
                })
            })
        })
    }